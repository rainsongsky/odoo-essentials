# -*- coding: utf-8 -*-

from odoo import http
from odoo.http import request

# class Hello(http.Controller):
#     # http://127.0.0.1:8069/helloworld
#     # import pudb; pudb.set_trace() 
#     @http.route('/helloworld', auth="public")
#     def helloworld(self):
#         return('<h1>Hello World!</h1>')

class Hello(http.Controller):
    # #http://127.0.0.1:8069/helloworld?querystring=test
    # @http.route('/helloworld', auth="public")
    # def helloworld(self, **kwargs):
    #     return request.render('library_website.helloworld')
    
    # #http://127.0.0.1:8069/hellocms/library_website.helloworld
    # @http.route('/hellocms/<page>', auth='public')
    # def hello(self, page, **kwargs):
    #     return http.request.render(page)
    
    #http://127.0.0.1:8069/helloworld?querystring=test
    @http.route('/helloworld', auth="public", website=True)
    def helloworld(self, **kwargs):
        return request.render('library_website.helloworld')
    