# -*- coding: utf-8 -*-

from operator import truediv
from odoo import fields, models, api

from odoo.exceptions import ValidationError

class Book(models.Model):
    #通过inherit继承增加字段
    _inherit = 'library.book'
    is_available = fields.Boolean('Is Available?')
    #通过in-place继承修改已有字段
    isbn = fields.Char(help="Use a valid ISBN-13 or ISBN-10.")
    publisher_id = fields.Many2one(index=True)

    def _check_isbn(self):
        self.ensure_one()
        isbn = self.isbn.replace('-', '')
        digits = [int(x) for x in isbn if x.isdigit()]
        if len(digits) == 10:
            ponderators = [1, 2, 3, 4, 5, 6, 7, 8, 9]
            total = sum(a * b for a, b in zip(digits[:9], ponderators))
            check = total % 11
            return digits[-1] == check
        else:
            return super()._check_isbn()

    def button_check_isbn(self):
        for book in self:
            if not book.isbn:
                raise ValidationError('Please provide an ISBN for %s' % book.name)
            if book.isbn and not book._check_isbn():
                raise ValidationError('%s is an invalid ISBN' % book.isbn)
        raise ValidationError('ISBN is OK')
        return true