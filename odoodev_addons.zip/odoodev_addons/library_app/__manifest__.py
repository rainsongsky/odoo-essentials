# -*- coding: utf-8 -*-
{
    'name': "Library Management",

    'summary': """
        Manage library catalog and book lending.""",

    'description': """
        Library Management Test
    """,

    'author': "Rainsong",
    'website': "http://www.openforge.cn",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/12.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Services/Library',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'views/library_menu.xml',
        'views/book_view.xml',
        'views/book_list_template.xml',
        'security/library_security.xml',
        'security/ir.model.access.csv',
        'reports/library_book_report.xml',
        'reports/library_book_sql_report.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        # 'demo/demo.xml',
        'demo/res.partner.csv',
        'demo/library.book.csv',
        "demo/book_demo.xml",
    ],
}