# -*- coding: utf-8 -*-

from . import checkout_mass_message
