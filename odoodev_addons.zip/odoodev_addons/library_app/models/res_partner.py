# -*- coding: utf-8 -*-

from odoo import fields, models

class Partner(models.Model):
    _inherit = 'res.partner'
    published_book_ids = fields.One2many(
        'library.book', # 关联模型
        'publisher_id', # fields for "this" on related model
        string='Published Books')